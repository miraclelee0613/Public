window.onload = function(){
    $('.header').load('../header_footer/header.html');
    console.log('11');
}

